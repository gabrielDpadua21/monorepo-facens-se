package br.com.valueprojects.estrategia_testes.controller_Integration;

import static org.junit.Assert.*;

import org.junit.Test;

public class UsuarioIntegrationTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
