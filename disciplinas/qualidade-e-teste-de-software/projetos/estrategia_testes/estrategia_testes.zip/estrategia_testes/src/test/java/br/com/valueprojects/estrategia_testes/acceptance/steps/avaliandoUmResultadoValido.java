package br.com.valueprojects.estrategia_testes.acceptance.steps;

import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;

import org.junit.Assert;

import br.com.valueprojects.estrategia_testes.model.*;

public class avaliandoUmResultadoValido {

	private Resultado resultado;
	private Jogo jogo;
	
		@Dado("um resultado valido")
		public void um_resultado_valido() {
			Participante participante = new Participante("Leonardo");
			resultado = new Resultado(participante , 150.0);
		}
		
		@Quando("o jogo esta acontecendo")
		public void o_jogo_esta_acontecendo() {
			
			jogo = new Jogo("Caca Moedas");
		}
		
		@Quando("o resultado eh anotado")
		public void o_resultado_eh_anotado() {
			jogo.anota(resultado);
		}
 		
		@Então("o resultado deve ser aceito")
		public void o_resultado_deve_ser_aceito() {
		 
			Assert.assertEquals(1, jogo.getResultados().size());
			Assert.assertEquals(150.0, jogo.getResultados().get(0).getMetrica(), 0.00001);
		}
}
	
	

