package br.com.valueprojects.estrategia_testes.e2e.selenium;

import static org.junit.Assert.*;

import org.junit.Test;

public class e2eJogoTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
