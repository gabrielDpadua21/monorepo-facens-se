package br.com.valueprojects.estrategia_testes.repository_Integration;

import static org.junit.Assert.*;

import org.junit.Test;

public class UsuarioRepository {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
