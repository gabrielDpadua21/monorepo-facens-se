package br.com.valueprojects.estrategia_testes.service_Integration;

import static org.junit.Assert.*;

import org.junit.Test;

public class JulgamentoServiceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
