package br.com.valueprojects.estrategia_testes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstrategiaTestesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstrategiaTestesApplication.class, args);
	}

}
